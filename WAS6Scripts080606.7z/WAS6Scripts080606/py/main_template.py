###############################################################################
# "This program may be used, executed, copied, modified and distributed without
# royalty for the purpose of developing, using, marketing, or distributing."
#
# Product 5630-A36 (C) COPYRIGHT International Business Machines Corp., 2006, 2007
# All Rights Reserved * Licensed Materials - Property of IBM
###############################################################################

#******************************************************************************
# File Name:   	main_template.py
# Description: 	Used for cut/paste into main.py
# Author:      	Gale Botwick - gbotwick@us.ibm.com
# History:     
#******************************************************************************

import sys
import java

execfile( WSADMIN_SCRIPTS_HOME+"/utils61.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/applications.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/environment.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/monitor.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/reports.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/resources.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/security.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverConfig.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverControl.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverSetup.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serviceIntegration.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/troubleshoot.py" )

# Note:  Functions are listed alphabetically in order to help locate them.  This is not 
#        the order in which they should be run due to dependencies.  

#===========================================================================================
#  Activate Server Trace
#===========================================================================================
print "\n** Activate Server Trace **"
# USAGE:  activateServerTrace ( <node name>, <server name>, <isRuntime>, <trace file>, <trace string> )


#===========================================================================================
#  Add Data Source Custom Properties
#===========================================================================================
print "\n** Add Data Source Custom Properties **"
# USAGE:  addDataSourceCustomProperties ( <scope>, <scopeName>, <dataSourceName>, <propName>,
							<propValue>, <propValueType>, <propDesc> )

#===========================================================================================
#  Add Preferred Servers to DefaultCoreGroup Policy
#===========================================================================================
print "\n** Add Preferred Servers to Default Core Group Policy **"
# USAGE:  addPrefServersToPolicy ( <policy name>, <server list> )


#===========================================================================================
#  Add Server or Cluster to SIB
#===========================================================================================
print "Add server or cluster to SI Bus"
# USAGE:  addServerOrClusterToSIB ( <bus name>, <server/cluster name>, <node name>, <dsJNDIName> )
# NOTE:   If this is for a cluster, the node name is ""
#         If this is for a server, the dsJNDIName is ""


#===========================================================================================
#  Add User or Group to the Messaging Bus
#===========================================================================================
print "Add User of Group to the Messaging Bus"
# USAGE:  addUserOrGroupToBus ( <bus name>, <user name>, <group name> )
# NOTE:   If this if for userName, the groupName is ""
#         If this is for groupName, the userName is ""


#===========================================================================================
#  Configure Custom User Registry
#===========================================================================================
print "\n** Create Custom User Registry **"
# USAGE:  configCustomUserRegistry ( <properties file name> )


#===========================================================================================
#  Configure Dynamic Cache
#===========================================================================================
print "\n** Configure Dynamic Cache **"
# USAGE:  configDynamicCache ( <properties file name> )


#===========================================================================================
#  Configure Global Security
#===========================================================================================
print "\n** Configure Global Security **"
# USAGE:  configGlobalSecurity ( <properties file name> )


#===========================================================================================
#  Configure LTPA
#===========================================================================================
print "\n** Configure LTPA **"
# USAGE:  configureLTPA ( <properties file name> )


#===========================================================================================
#  Configure SSL
#===========================================================================================
print "\n** Configure SSL **"
# USAGE:  configureSSL ( <properties file name> )


#===========================================================================================
#  Configure SSO
#===========================================================================================
print "\n** Configure SSO **"
# USAGE:  configureSSO ( <properties file name> )


#===========================================================================================
#  Configure Web Container Session Manager
#===========================================================================================
print "\n** Configure Web Container Session Manager **"
# USAGE:  configWebContainerSessionMgr ( <properties file name> )


#===========================================================================================
#  Create Cluster
#===========================================================================================
print "\n** Create Cluster **"
# USAGE:  createCluster ( <"cluster name">, <"pref local">, <"rep domain"> )


#===========================================================================================
#  Create Cluster Member
#===========================================================================================
print "\n** Create Cluster Member **"
# USAGE:  createClusterMember ( <"cluster member name">, <"cluster name">, <"node name">, <"weight"> )


#===========================================================================================
#  Create Cluster With Member
#===========================================================================================
print "\n** Create Cluster Member **"
# USAGE:  createClusterWithMember ( <"cluster name">, <"node name">, <"server name"> )


#===========================================================================================
#  Create Data Source
#===========================================================================================
print "\n** Create Data Source **"
# USAGE:  createDataSource ( <properties file name> )


#===========================================================================================
#  Create J2C Aliases
#===========================================================================================
print "\n** Create J2C Aliases **"
# USAGE:  createJAASAuthAlias ( <alias name>, <userid>, <password>, <description> )


#===========================================================================================
#  Create JDBC Provider
#===========================================================================================
print "\n** Create JDBC Provider **"
# USAGE:  createJDBCProvider ( <properties file name > )


#===========================================================================================
#  Create JMS Activation Spec
#===========================================================================================
print "\n** Create JMS Activation Spec **"
# USAGE:  createJMSActivationSpec ( <properties file name> )

#===========================================================================================
#  Modify JMS Activation Spec
#===========================================================================================
print "\n** Modify JMS Activation Spec **"
# USAGE:  modifyJMSActivationSpec ( <properties file name> )


#===========================================================================================
#  Create JMS Connection Factory
#===========================================================================================
print "\n** Create JMS Connection Factory **"
# USAGE:  createJMSConnectionFactory ( <properties file name> )


#===========================================================================================
#  Create JMS Provider
#===========================================================================================
print "\n** Create JMS Provider **"
# USAGE:  createJMSProvider ( <properties file name> )


#===========================================================================================
#  Create JMS Queue
#===========================================================================================
print "\n** Create JMS Queue **"
# USAGE:  createJMSQueue ( <properties file name> )


#===========================================================================================
#  Create JMS Topic
#===========================================================================================
print "\n** Create JMS Topic **"
# USAGE:  createJMSTopic ( <properties file name> )


#===========================================================================================
#  Create JVM Custom Property
#===========================================================================================
print "\n** Create JVM Custom Property **"
# USAGE:  createJVMProperty ( <node name>, <server name>, <"name">, <"value">, <"description"> )


#===========================================================================================
#  Create Mail Session on Built-in Mail Provider
#===========================================================================================
print "\n** Create Mail Session **"
# USAGE:  createMailSession ( <properties file name> )


#===========================================================================================
#  Create MQ Connection Factory
#===========================================================================================
print "\n** Create MQ Connection Factory **"
# USAGE:  createMQConnectionFactory ( <properties file name> )


#===========================================================================================
#  Create Name Space Binding
#===========================================================================================
print "\n** Create Name Space Binding **"
# USAGE:  createNameSpaceBinding ( <properties file name> )


#===========================================================================================
#  Create Replication Domain
#===========================================================================================
print "\n** Create Replication Domain **"
# USAGE:  createReplicationDomain ( <properties file name> )


#===========================================================================================
#  Create Replicator
#===========================================================================================
print "\n** Create Replicator **"
# USAGE:  createReplicator ( <properties file name> )


#===========================================================================================
#  Create Scheduler
#===========================================================================================
print "\n** Create Scheduler **"
# USAGE:  createScheduler ( <properties file name> )


#==========================================================================================
#  Create Server
#==========================================================================================
print "\n** Create Server **"
# USAGE: createServer ( <"node name">, <"server name">, <"host name">, <"dns host"> )


#===========================================================================================
#  Create Shared Library
#===========================================================================================
print "\n** Create Shared Library **"
# USAGE:  createSharedLibrary ( <properties file name> )


#===========================================================================================
#  Create SIB Destination
#===========================================================================================
print "\n** Create SIB Destination **"
# USAGE:  createSIBDestination ( <properties file name> )


#===========================================================================================
#  Create SI Bus
#===========================================================================================
print "\n** Create SI Bus **"
# USAGE:  createSIBus ( <properties file name> )


#===========================================================================================
#  Create URL
#===========================================================================================
print "\n** Create URL **"
# USAGE:  createURL ( <properties file name> )


#===========================================================================================
#  Create URL Custom Property
#===========================================================================================
print "\n** Create URL Custom Property **"
# USAGE:  createURLCustomProperty ( <properties file name> )


#===========================================================================================
#  Create URL Provider
#===========================================================================================
print "\n** Create URL Provider **"
# USAGE:  createURLProvider ( <properties file name> )


#===========================================================================================
#  Create WebSphere Environment Variable
#===========================================================================================
print "\n** Create WebSphere Environment Variable **"
# USAGE:  createWebSphereVariable ( <scope>, <scope name>, <node name>, <name>, <value> )


#===========================================================================================
#  Create Work Manager
#===========================================================================================
print "\n** Create Work Manager **"
# USAGE:  createWorkManager ( <properties file name> )


#===========================================================================================
#  Deactivate Server Trace
#===========================================================================================
print "\n** Deactivate Server Trace **"
# USAGE:  deactivateServerTrace ( <node name>, <server name>, <isRuntime> )


#===========================================================================================
#  Dump Threads
#===========================================================================================
print "\n** Dump Threads **"
# USAGE:  dumpThreads ( <node name>, <server name> )


#===========================================================================================
#  Mark App State
#===========================================================================================
print "\n** Mark App State **"
# USAGE:  markAppState ( <app version>, <isEnabled> )


#===========================================================================================
#  Modify JAAS Auth Alias
===========================================================================================
print "\n** Modify JAAS Auth Alias **"
# USAGE:  modifyJ2CAuthData ( <alias name>, <userId>, <password>, <description> )


#===========================================================================================
#  Remove Data Source
#===========================================================================================
print "\n** Remove Data Source **"
# USAGE:  removeDataSource ( <scope>, <scope name>, <datasource name> )


#===========================================================================================
#  Remove JDBC Provider
#===========================================================================================
print "\n** Remove JDBC Provider **"
# USAGE:  removeJDBCProvider ( <scope>, <scope name>, <provider name> )


#===========================================================================================
#  Remove User or Group from the Messaging Bus
#===========================================================================================
print "\n** Remove User of Group from the Messaging Bus **"
# USAGE:  removeUserOrGroupFromBus ( <bus name>, <user name>, <group name> )
# NOTE:   If this if for userName, the groupName is ""
#         If this is for groupName, the userName is ""

#===========================================================================================
#  Remove WebSphere Environment Variable
#===========================================================================================
print "\n** Remove WebSphere Environment Variable **"
# USAGE:  removeWebSphereVariable ( <scope>, <scope name>, <node name>, <name> )


#===========================================================================================
#  Restart Servers
#===========================================================================================
print "\n** Restart Servers **"
# USAGE:   goRestartServers ( <"server list"> )
# EXAMPLE: goRestartServers ( "server1, server2" )


#===========================================================================================
#  Set Cluster Member Weight
#===========================================================================================
print "\n** Set Cluster Member Weight **"
# USAGE:  setClusterMemberWeight ( <member name>, <weight> )


#===========================================================================================
#  Set Custom User Registry (CUR) Custom Properties 
#===========================================================================================
print "\n** Set CUR Custom Properties **"
# USAGE:  setCURCustomProperties ( <name>, <value>, <description> )


#===========================================================================================
#  Set DB Pool Max Connections
#===========================================================================================
print "\n** Set DB Pool Max Connections **"
# USAGE:  setDBPoolMaxConnections ( <scope>, <scope name>, <data source name>, <value> )


#===========================================================================================
#  Set Initial State
#===========================================================================================
print "\n** Set Applicaiton Server Initial State **"
# USAGE:   setInitialState ( <"server list">, <"init state"> )
# EXAMPLE: setInitialState ( "server1 server2", "START" )



#===========================================================================================
#  Set JVM Arguments
#===========================================================================================
print "\n** Set JVM Arguments **"
# USAGE:   setJVMArguments ( <"server list">, <"jvm args"> )
# EXAMPLE: setJVMArguments ( "server1 server2", "-DDatabaseEnv=prism:client -DConnCopReg=was -DClient=orlando" )

#===========================================================================================
#  Set JVM Classpath
#===========================================================================================
print "\n** Set JVM Classpath **"
# USAGE:   setJVMClasspath ( <"server list">, <"jvm classpath"> )
# EXAMPLE: setJVMClasspath ( "server1 server2", "/usr/lpp/db2_07_01/java12/db2java.zip" )


#===========================================================================================
#  Set JVM Debug Arguments
#===========================================================================================
print "\n** Set JVM Debug Arguments **"
# USAGE:   setJVMDebugArguments ( <"server list">, <"jvm debug args"> )
# EXAMPLE: setJVMDebugArguments ( "server1 server2", "-Djava.compiler=NONE -Xdebug -Xnoagent" )


#===========================================================================================
#  Set JVM Debug Mode
#===========================================================================================
print "\n** Set Debug Mode **"
# USAGE:   setJVMDebugMode ( <"server list">, <"debug mode"> )
# EXAMPLE: setJVMDebugMode ( "server1 server2", "true" )


#===========================================================================================
#  Set JVM Heap Sizes
#===========================================================================================
print "\n** Set JVM Heap Sizes **"
# USAGE:   setJVMHeapSizes ( <"server list">, <"min heap size">, <"max heap size"> )
# EXAMPLE: setJVMHeapSizes ( "server1 server2", "256", "1024" )


#===========================================================================================
#  Set JVM Verbose GC
#===========================================================================================
print "Set JVM Verbose GC"
# USAGE:   setJVMVerboseGC ( <"server list">, <"gcFlag"> )
# EXAMPLE: setJVMVerboseGC ( "server1 server2", "true" )


#===========================================================================================
#  Set Max in Memory Session Count
#===========================================================================================
print "\n** Set Max in Memory Session Count **"
# USAGE:   setMaxInMemorySessionCount ( <"server list">, <"size"> )
# EXAMPLE: setMaxInMemorySessionCount ( "server1 server2", "2000" )


#===========================================================================================
#  Set ORB Request Timeout
#===========================================================================================
print "\n** Set ORB Request Timeout **"
# USAGE:   setORBRequestTimeout ( <"server list">, <"value"> )
# EXAMPLE: setORBRequestTimeout ( "server1 server2", "300" )


#===========================================================================================
#  Set Pass By Reference
#===========================================================================================
print "\n** Set Pass By Reference **"
# USAGE:   setPassByReference ( <"server list">, <"value"> )
# EXAMPLE: setPassByReference ( "server1 server2", "true" )



#===========================================================================================
#  Set Web Container Servlet Caching
#===========================================================================================
print "\n** Set Web Container Servlet Caching **"
# USAGE:   setWebContainerServletCaching ( <"server list">, <"sc flag"> )
# EXAMPLE: setWebContainerServletCaching ( "server1 server2", "true" )


#===========================================================================================
#  Set Web Container Thread Pool Is Growable
#===========================================================================================
print "\n** Set Web Container Thread Pool Is Growable **"
# USAGE:   setWebContainerThreadPoolIsGrowable ( <"server list">, <"gflag"> )
# EXAMPLE: setWebContainerThreadPoolIsGrowable ( "server1 server2", "true" )


#===========================================================================================
#  Set Web Container Thread Pool Sizes
#===========================================================================================
print "\n** Set Web Container Thread Pool Sizes **"
# USAGE:   setWebContainerThreadPoolSizes ( <"server list">, <"min size">, <"max size"> )
# EXAMPLE: setWebContainerThreadPoolSizes ( "server1 server2", "5", "65" )

#===========================================================================================
#  Show all Data Sources  (report)
#===========================================================================================
print "\n** Show All Data Sources **"
# USAGE:  showAllDataSources


#===========================================================================================
#  Show all Environment Variables (report)
#===========================================================================================
print "\n** Show All Environment Variables **"
# USAGE:  showAllEnvVars


#===========================================================================================
#  Show App State (report)
#===========================================================================================
print "\n** Show App State **"
# USAGE:  showAppState


#===========================================================================================
#  Show Cluster Info (report)
#===========================================================================================
print "\n** Show Cluster Info **"
# USAGE:  showClusterInfo


#===========================================================================================
#  Show Running Status (report)
#===========================================================================================
print "\n** Show Running Status **"
# USAGE:  showRunningStatus


#===========================================================================================
#  Show Server Info (report)
#===========================================================================================
print "\n** Show Server Info **"
# USAGE:  showServerInfo


#===========================================================================================
#  Start App
#===========================================================================================
print "\n** Start App **"
# USAGE:  startApp ( <app name>, <server name> )


#===========================================================================================
#  Start Cluster
#===========================================================================================
print "\n** Start Cluster **"
# USAGE:  goStartCluster ( <"cluster name"> )


#===========================================================================================
#  Start Clusters
#===========================================================================================
print "\n** Start Clusters **"
# USAGE:  goStartClusters ( <"cluster list"> )
# EXAMPLE: goStartClusters ( "cluster1,cluster2" )



#===========================================================================================
#  Start Server
#===========================================================================================
print "\n** Start Server **"
# USAGE:  goStartServer ( <"node name">, <"server name"> )


#===========================================================================================
#  Start Servers
#===========================================================================================
print "\n** Start Servers **"
# USAGE:   goStartServers ( <"server list"> )
# EXAMPLE: goStartServers ( "server1,server2" )


#===========================================================================================
#  Stop App
#===========================================================================================
print "\n** Stop App **"
# USAGE:  stopApp ( <"app name">, <"server name"> )


#===========================================================================================
#  Stop Cluster
#===========================================================================================
print "\n** Stop Cluster **"
# USAGE:  goStopCluster ( <"cluster name"> )


#===========================================================================================
#  Stop Clusters
#===========================================================================================
print "\n** Stop Clusters **"
# USAGE:   goStopClusters ( <"cluster list"> )
# EXAMPLE: goStopClusters ( "cluster1,cluster2" )


#===========================================================================================
#  Stop Server
#===========================================================================================
print "\n** Stop Server **"
# USAGE:  goStopServer ( <"node name">, <"server name"> )


#===========================================================================================
#  Stop Servers
#===========================================================================================
print "\n** Stop Servers **"
# USAGE:   goStopServers ( <"server list"> )
# EXAMPLE: goStopServers ( "server1,server2" )


#===========================================================================================
#  Toggle Performance Monitor
#===========================================================================================
print "\n** Toggle Performance Monitor **"
# USAGE:  togglePerfMonitor ( <node name>, <server name>, <flag> )


#===========================================================================================
#  Toggle SIB Service
#===========================================================================================
print "\n** Toggle SIB Service **"
# USAGE:  toggleSIBService ( <node name>, <server name>, <flag> )


#===========================================================================================
#  Save Configuration
#===========================================================================================
print "\n====== Saving configuration  ======"
AdminConfig.save()
syncNodesToMaster( nodeList )

print 'Done ...'




