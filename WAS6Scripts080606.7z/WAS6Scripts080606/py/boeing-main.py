###############################################################################
# "This program may be used, executed, copied, modified and distributed without
# royalty for the purpose of developing, using, marketing, or distributing."
#
# Product 5630-A36 (C) COPYRIGHT International Business Machines Corp., 2006, 2007
# All Rights Reserved * Licensed Materials - Property of IBM
###############################################################################

#******************************************************************************
# File Name:   	main_template.py
# Description: 	Used for cut/paste into main.py
# Author:      	Gale Botwick - gbotwick@us.ibm.com
#		Mannie Kagan - kagan@ca.ibm.com
# History:     
#******************************************************************************

import sys
import java

execfile( WSADMIN_SCRIPTS_HOME+"/utils6.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/applications.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/environment.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/monitor.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/reports.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/resources.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/boeing_resources.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/security.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverConfig.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverControl.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverSetup.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serviceIntegration.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/troubleshoot.py" )

#===========================================================================================
#  Show Server Info (report)
#===========================================================================================
#print "\n** Show Server Info **"
# USAGE:  showServerInfo
#showServerInfo()

#===========================================================================================
#  Show Running Status (report)
#===========================================================================================
#print "\n** Show Running Status **"
# USAGE:  showRunningStatus
#showRunningStatus()

#===========================================================================================
#  List JMS Activation Specs
#===========================================================================================
print "\n** List JMS Activation Specs property **"
# USAGE:  listJMSActivationSpecs ( <properties file name> )
listJMSActivationSpecs_property ( PROPS_HOME+"boeing_listJMSActivationSpec.props" )

#===========================================================================================
#  Modify JMS Activation Spec
#===========================================================================================
print "\n** Modify JMS Activation Spec MaxConcurrency **"
# USAGE:  modifyJMSActivationSpecMaxConcurrency ( <properties file name> )
modifyJMSActivationSpecMaxConcurrency ( PROPS_HOME+"boeing_modifyJMSActivationSpec_MidTier.IBackEndJMSImport3_AS.props" )
modifyJMSActivationSpecMaxConcurrency ( PROPS_HOME+"boeing_modifyJMSActivationSpec_BPEInternalActivationSpec.props" )

#===========================================================================================
#  List JCA Activation Specs
#===========================================================================================
print "\n** List JCA Activation Specs property=maxConcurrency **"
# USAGE:  listJ2CActivationSpecs ( <properties file name> )
listJ2CActivationSpecs_property ( PROPS_HOME+"boeing_listJ2CActivationSpec.props" )

#===========================================================================================
#  Modify JCA Activation Spec
#===========================================================================================
print "\n** Modify JCA Activation Spec MaxConcurrency **"
# USAGE:  modifyJ2CActivationSpecMaxConcurrency ( <properties file name> )
modifyJ2CActivationSpecMaxConcurrency ( PROPS_HOME+"boeing_modifyJ2CActivationSpec_MidTier_AS.props" )

#===========================================================================================
#  Save Configuration
#===========================================================================================
print "\n====== Saving configuration  ======"
#
AdminConfig.save()
#syncNodesToMaster( nodeList )

print 'Done ...'




