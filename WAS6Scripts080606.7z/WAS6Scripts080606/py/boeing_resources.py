###############################################################################
# "This program may be used, executed, copied, modified and distributed without
# royalty for the purpose of developing, using, marketing, or distributing."
#
# Product 5630-A36 (C) COPYRIGHT International Business Machines Corp., 2006, 2007
# All Rights Reserved * Licensed Materials - Property of IBM
###############################################################################

#******************************************************************************
# File Name:	resources.py
# Description:	This file contains the following resources procedures:
#		
#			listJMSActivationSpecs_property
#			modifyJMSActivationSpecMaxConcurrency
#			listJ2CActivationSpecs_property
#			modifyJ2CActivationSpecMaxConcurrency
#
# Author:		Mannie Kagan - kagan@ca.ibm.comm
#
# History:		
#			
#******************************************************************************
#******************************************************************************
# Procedure:   	listJMSActivationSpecs_property
# Description:	List existing JMS Activation Specifications single specified property
# Author:      	Mannie Kagan - kagan@ca.ibm.com
#
# History:	
#****************************************************************************** 
def listJMSActivationSpecs_property ( propertyFileName ):

	readProperties(propertyFileName)

	scope =		getProperty("SCOPE")
	scopeName = 	getProperty("SCOPE_NAME")
	property1 =	getProperty("PROPERTY1")
	# more go here ......

	#------------------------------------------------------------------------------
	# List JMS Activation Specifications
	#------------------------------------------------------------------------------
	global AdminTask
	scopeId = findScopeEntry(scope, scopeName)
	if (scopeId == 0):
		print "Unable to find "+scopeName 
		return
	#endIf

	# Get JMS Activation Specs
	asList = AdminTask.listSIBJMSActivationSpecs(scopeId).split(lineSeparator)

	for item in asList:
		#print item
		asname = item.split("(")[0]
		print asname
		asDetail = AdminTask.showSIBJMSActivationSpec(item ).split(",")
		for detail in asDetail:
			if( detail.startswith(" "+property1) ): #prepended space
				print "\t\t\t"+detail
			#endif
		#endfor
	#endFor

	print "** JMS Activation Specifications property listed."
	
#endDef
#******************************************************************************
# Procedure:   	modifyJMSActivationSpecMaxConcurrency
# Description:	Modify an existing JMS Activation Specification
# Author:      	Mannie Kagan - kagan@ca.ibm.com
#
# History:	
#****************************************************************************** 
def modifyJMSActivationSpecMaxConcurrency ( propertyFileName ):

	readProperties(propertyFileName)

	scope =		getProperty("SCOPE")
	scopeName = 	getProperty("SCOPE_NAME")
	name = 		getProperty("NAME")
	jndiName = 	getProperty("JNDI_NAME")
	destJndiName=	getProperty("DEST_JNDI_NAME")
	busName = 	getProperty("BUSNAME")
	maxConcurrency = getProperty("MAX_CONCURRENCY")

	#------------------------------------------------------------------------------
	# Modify JMS Activation Specification
	#------------------------------------------------------------------------------
	global AdminTask

	scopeId = findScopeEntry(scope, scopeName)
	if (scopeId == 0):
		print "Unable to find "+scopeName 
		return
	#endIf

	# Check if the activation specification exists
	asList = AdminTask.listSIBJMSActivationSpecs(scopeId).split(lineSeparator)

	found = "false"

	for item in asList:
		if (item.find(name) >= 0):
			print ""+name+" exists..... continuing"
			target = item
			found = "true"
			break
		#endIf
	#endFor

	if( found == "false" ):
		print ""+name+" does not exist! ..... returning"
		return
	#endIf

	parms  = '-name "'+name+'" -jndiName '+jndiName+' -destinationJndiName "'+destJndiName+'" -busName "'+busName+'"'
	parms1 = ' -maxConcurrency '+maxConcurrency+''
	
	parms += parms1

	#print parms

	try:
		_excp_ = 0
		print "\tSetting Activation Spec: "+name+": "+parms1
		as = AdminTask.modifySIBJMSActivationSpec(target,parms)
	except:
		_type_, _value_, _tbck_ = sys.exc_info()
		as = `_value_`
		_excp_ = 1
	#endTry 
	if (_excp_ ):
		print "Error modifying JMS Activation Spec"
		print "Error = "+as
		return
	#endIf 	

	AdminConfig.save()
	print "** JMS Activation Specification successfully modified."
	
#endDef

#******************************************************************************
# Procedure:   	listJ2CActivationSpecs_property
# Description:	List existing J2C Activation Specifications single specified property
# Author:      	Mannie Kagan - kagan@ca.ibm.com
#
# History:	
#****************************************************************************** 
def listJ2CActivationSpecs_property ( propertyFileName ):

	readProperties(propertyFileName)

	scope =		getProperty("SCOPE")
	scopeName = 	getProperty("SCOPE_NAME")
	nodeName =	getProperty("NODE_NAME")
	property1=	getProperty("PROPERTY1")

	#------------------------------------------------------------------------------
	# List J2C Activation Specifications
	#------------------------------------------------------------------------------
	global AdminTask
	scopeId = findScopeEntry(scope, scopeName)
	if (scopeId == 0):
		print "Unable to find "+scopeName 
		return
	#endIf
	
	rraName = rraName = "Platform Messaging Component SPI Resource Adapter"
	rraId = getConfigItemId(scope, scopeName, nodeName, "J2CResourceAdapter", rraName)
	
	if (rraId == 0):
		print "Unable to find "+rraId+"! ..... returning"
		return
	#endIf
	
	# Get J2C Activation Specs
	asList = AdminTask.listJ2CActivationSpecs(rraId, '[-messageListenerType com.ibm.wsspi.sib.ra.SibRaMessageListener]').split(lineSeparator)

	for item in asList:
		asname=item.split("(")[0]
		print asname
		propList = AdminConfig.list( 'J2EEResourceProperty', item ).split(lineSeparator)
		for prop in propList:
			if( prop.startswith(property1) ):
				print '\t\t\t'+property1+'='+AdminConfig.showAttribute( prop, 'value' )
				# new ones go here .....
			#endif
		#endfor
	#endFor

	print "** J2CActivation Specifications property listed."
	
#endDef
#******************************************************************************
# Procedure:   	modifyJ2CActivationSpecMaxConcurrency
# Description:	Modify an existing J2C Activation Specification
# Author:      	Mannie Kagan - kagan@ca.ibm.com
#
# History:	
#****************************************************************************** 
def modifyJ2CActivationSpecMaxConcurrency ( propertyFileName ):

	readProperties(propertyFileName)

	scope =		getProperty("SCOPE")
	scopeName = 	getProperty("SCOPE_NAME")
	nodeName =	getProperty("NODE_NAME")
	asName =	getProperty("NAME")
	maxConcurrency=	getProperty("MAX_CONCURRENCY")

	#------------------------------------------------------------------------------
	# Modify JMS Activation Specification
	#------------------------------------------------------------------------------
	global AdminTask
	scopeId = findScopeEntry(scope, scopeName)
	if (scopeId == 0):
		print "Unable to find "+scopeName 
		return
	#endIf
	
	rraName = rraName = "Platform Messaging Component SPI Resource Adapter"
	rraId = getConfigItemId(scope, scopeName, nodeName, "J2CResourceAdapter", rraName)
	
	if (rraId == 0):
		print "Unable to find "+rraId 
		return
	#endIf
	
	# Get J2C Activation Specs
	asList = AdminTask.listJ2CActivationSpecs(rraId, '[-messageListenerType com.ibm.wsspi.sib.ra.SibRaMessageListener]').split(lineSeparator)

	for item in asList:
		#print item.split("(")[0]
		if( item.split("(")[0] == asName ):
			#print asName
			propList = AdminConfig.list( 'J2EEResourceProperty', item ).split(lineSeparator)
			for prop in propList:
				if( prop.split("(")[0] == 'maxConcurrency' ):
					print "\tSetting Activation Spec: "+asName+": "+'maxConcurrency='+maxConcurrency
					AdminConfig.modify(prop, [['value', maxConcurrency]])
					# new ones go here .....
				#endif	
			#endfor	
		#endif	
	#endFor

	AdminConfig.save()
	print "** JMS Activation Specification successfully modified."
	
#endDef

