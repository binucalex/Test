###############################################################################
# "This program may be used, executed, copied, modified and distributed without
# royalty for the purpose of developing, using, marketing, or distributing."
#
# Product 5630-A36 (C) COPYRIGHT International Business Machines Corp., 2006, 2007
# All Rights Reserved * Licensed Materials - Property of IBM
###############################################################################

#******************************************************************************
# File Name:   	main.py
# Description: 	Used for script flow.
# Author:      	Gale Botwick - gbotwick@us.ibm.com
# History:     
#******************************************************************************

import sys
import java

execfile( WSADMIN_SCRIPTS_HOME+"/utils6.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/applications.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/environment.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/monitor.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/reports.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/resources.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/security.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverConfig.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverControl.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serverSetup.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/serviceIntegration.py" )
execfile( WSADMIN_SCRIPTS_HOME+"/troubleshoot.py" )

#==========================================================================================
#  Create Server
#==========================================================================================
print "\n** Create Server **"
# USAGE: createServer ( <"node name">, <"server name">, <"host name">, <"dns host"> )
createServer ( "dopeyNode01", "StandaloneTrainingServer", "default_host", "*" )
createServer ( "sleepyNode", "sneezy mitretek org", "default_host", "*" )

#===========================================================================================
#  Create Cluster
#===========================================================================================
print "\n** Create Cluster **"
# USAGE:  createCluster ( <"cluster name">, <"pref local">, <"rep domain"> )
createCluster ( "RASMASWebCluster", "true", "true" )
createCluster ( "RASMASMessagingCluster", "true", "true" )

#===========================================================================================
#  Create Cluster Member
#===========================================================================================
print "\n** Create Cluster Member **"
# USAGE:  createClusterMember ( <"cluster member name">, <"cluster name">, <"node name">, <weight> )
createClusterMember ( "RASMASMessaging01", "RASMASMessagingCluster", "sleepyNode", "2" )
createClusterMember ( "RASMASMessaging02", "RASMASMessagingCluster", "dopeyNode01", "2" )
createClusterMember ( "RASMASWebAS01", "RASMASWebCluster", "sleepyNode", "2" )
createClusterMember ( "RASMASWebAS02", "RASMASWebCluster", "dopeyNode01", "10" )

#===========================================================================================
#  Add Preferred Servers to DefaultCoreGroup Policy
#===========================================================================================
print "\n** Add Preferred Servers to Default Core Group Policy **"
# USAGE:  addPrefServersToPolicy ( <"policy name">, <"server list"> )
addPrefServersToPolicy ( "Default SIBus Policy", "RASMASMessaging01" )

#===========================================================================================
#  Create WebSphere Environment Variable
#===========================================================================================
print "\n** Create WebSphere Environment Variable **"
# USAGE:  createWebSphereVariable ( <"scope">, <scope name>, <"node name">, <"name">, <"value"> )
createWebSphereVariable ( "cell", cellName, "", "WAS_INSTALL_ROOT", "/opt/IBM/WebSphere/AppServer" )
createWebSphereVariable ( "cell", cellName, "", "ORACLE_JDBC_DRIVER_PATH", "${WAS_INSTALL_ROOT}/lib/ext" )

#===========================================================================================
#  Create Mail Session on Built-in Mail Provider
#===========================================================================================
print "\n** Create Mail Session **"
# USAGE:  createMailSession ( <"properties file name"> )
createMailSession ( PROPS_HOME+"mailSession.props" )

#===========================================================================================
#  Create J2C Aliases
#===========================================================================================
print "\n** Create J2C Aliases **"
# USAGE:  createJ2CAuthData ( <"alias name">, <"userid">, <"password">, <"description"> )
createJ2CAuthData ( "sleepyCellManager/ApplicationDatabaseAlias", "sample01", "", "" )
createJ2CAuthData ( "sleepyCellManager/RASMASBus Connect alias", "sample02", "", "Alias to connect to RASMASBus" )
createJ2CAuthData ( "sleepyCellManager/RASMASBus TABLES Alias", "sample03", "", "Alias messaging engine use to connect to DB" )
createJ2CAuthData ( "sleepyCellManager/Training Database Alias", "sample04", "", "J2C for Training Database" )

#===========================================================================================
#  Create JDBC Provider
#===========================================================================================
print "\n** Create JDBC Provider **"
# USAGE:  createJDBCProvider ( <properties file name > )
createJDBCProvider ( PROPS_HOME+"JDBCOracleProvider.props" )

#===========================================================================================
#  Create Data Source
#===========================================================================================
print "\n** Create Data Source **"
# USAGE:  createDataSource ( <"properties file name"> )
createDataSource ( PROPS_HOME+"dsTestRailTraining.props" )

#===========================================================================================
#  Configure Custom User Registry
#===========================================================================================
print "\n** Configure Custom User Registry **"
# USAGE:  configCustomUserRegistry ( <"properties file name"> )
configCustomUserRegistry ( PROPS_HOME+"Security.props" )

#===========================================================================================
#  Configure LTPA
#===========================================================================================
print "\n** Configure LTPA **"
# USAGE:  configureLTPA ( <"properties file name"> )
configureLTPA ( PROPS_HOME+"Security.props" )

#===========================================================================================
#  Configure SSO
#===========================================================================================
print "\n** Confgure SSO **"
# USAGE:  configureSSO ( <"properties file name"> )
configureSSO ( PROPS_HOME+"Security.props" )

#===========================================================================================
#  Configure SSL
#===========================================================================================
print "\n** Configure SSL **"
# USAGE:  configureSSL ( <"properties file name"> )
configureSSL ( PROPS_HOME+"dopeyNodeSSL.props" )
configureSSL ( PROPS_HOME+"sleepyCellSSL.props" )
configureSSL ( PROPS_HOME+"sleepyNodeSSL.props" )

#===========================================================================================
#  Configure Global Security
#===========================================================================================
print "\n** Configure Global Security **"
# USAGE:  configGlobalSecurity ( <"properties file name"> )
configGlobalSecurity ( PROPS_HOME+"Security.props" )

#===========================================================================================
#  Set JVM Verbose GC
#===========================================================================================
print "\n** Set JVM Verbose GC **"
# USAGE:   setJVMVerboseGC ( <"serverList">, <"gcFlag"> )
# EXAMPLE: setJVMVerboseGC ( "server1 server2", "true" )
setJVMVerboseGC ( "RASMASWebAS01", "true" )

#===========================================================================================
#  Set JVM Heap Sizes
#===========================================================================================
print "\n** Set JVM Heap Sizes **"
# USAGE:   setJVMHeapSizes ( <"server list">, <"min heap size">, <"max heap size"> )
# EXAMPLE: setJVMHeapSizes ( "server1 server2", "256", "1024" )
setJVMHeapSizes ( "RASMASWebAS01", "384", "512" )


#===========================================================================================
#  Set JVM Debug Mode
#===========================================================================================
print "\n** Set Debug Mode **"
# USAGE:   setJVMDebugMode ( <"server list">, <"debug mode"> )
# EXAMPLE: setJVMDebugMode ( "server1 server2", "true" )
setJVMDebugMode ( "RASMASWebAS01", "true" )


#===========================================================================================
#  Set JVM Debug Arguments
#===========================================================================================
print "\n** Set JVM Debug Arguments **"
# USAGE:   setJVMDebugArguments ( <"server list">, <"jvm debug args"> )
# EXAMPLE: setJVMDebugArguments ( "server1 server2", "-Djava.compiler=NONE -Xdebug -Xnoagent" )
setJVMDebugArguments ( "RASMASWebAS01", "XXXYYY,suspend=n,address=7778" )


#===========================================================================================
#  Set JVM Arguments
#===========================================================================================
print "\n** Set JVM Arguments **"
# USAGE:  setJVMArguments ( <"serverList">, <"JVM arguments"> )
setJVMArguments ( "RASMASWebAS01", "-Dibm.was.enable.wsjar.connection.getcontexttype=true -Djava.awt.headless=true" )

#===========================================================================================
#  Create JVM Custom Property
#===========================================================================================
print "\n** Create JVM Custom Property **"
# USAGE:  createJVMProperty ( <"node name">, <"server name">, <"name">, <"value">, <"description"> )
createJVMProperty ( "sleepyNode", "RASMASMessaging01", "JITC COMPILEOPT", "COMPILING", "Per PMR Request" )

#===========================================================================================
#  Create SI Bus
#===========================================================================================
print "\n** Create SI Bus **"
# USAGE:  createSIBus ( <"properties file name"> )
createSIBus ( PROPS_HOME+"SIBus.props" )

#===========================================================================================
#  Add Server to SIB
#===========================================================================================
print "\n** Add server or cluster to SI Bus **"
# USAGE:  addServerOrClusterToSIB ( <"bus name">, <"server/cluster name">, <"node name">, <"dsJNDIName"> )
# NOTE:   If this is for a cluster, the node name is ""
#         If this is for a server, the dsJNDIName is ""
addServerOrClusterToSIB ( "RASMASBus", "RASMASMessagingCluster", "", "jdbc/rasmasMsg" )

#===========================================================================================
#  Create SIB Destinations
#===========================================================================================
print "\n** Create SIB Destinations **"
# USAGE:  createSIBDestination ( <"properties file name"> )
createSIBDestination ( PROPS_HOME+"FacilityRelDest.props" )
createSIBDestination ( PROPS_HOME+"NRCPubTopicDest.props" )

#===========================================================================================
#  Remove User or Group from the Messaging Bus
#===========================================================================================
print "\n** Remove User of Group from the Messaging Bus **"
# USAGE:  removeUserOrGroupFromBus ( <"bus name">, <"user name">, <"group name"> )
# NOTE:   If this if for userName, the groupName is ""
#         If this is for groupName, the userName is ""
removeUserOrGroupFromBus ( "RASMASBus", "", "AllAuthenticated" )

#===========================================================================================
#  Add User or Group to the Messaging Bus
#===========================================================================================
print "\n** Add User of Group to the Messaging Bus **"
# USAGE:  addUserOrGroupToBus ( <"bus name">, <"user name">, <"group name"> )
# NOTE:   If this if for userName, the groupName is ""
#         If this is for groupName, the userName is ""
addUserOrGroupToBus ( "RASMASBus", "redactedUserSameAsCUR", "" )

#===========================================================================================
#  Create JMS Connection Factory
#===========================================================================================
print "\n** Create JMS Connection Factory **"
# USAGE:  createJMSConnectionFactory ( <"properties file name"> )
createJMSConnectionFactory ( PROPS_HOME+"ReleaseCF.props" )

#===========================================================================================
#  Create JMS Queue
#===========================================================================================
print "\n** Create JMS Queue **"
# USAGE:  createJMSQueue ( <"properties file name"> )
createJMSQueue ( PROPS_HOME+"FacilityRelQueue.props" )

#===========================================================================================
#  Create JMS Topic
#===========================================================================================
print "\n** Create JMS Topic **"
# USAGE:  createJMSTopic ( <"properties file name"> )
createJMSTopic ( PROPS_HOME+"NCRPubTopic.props" )

#===========================================================================================
#  Create JMS Activation Spec
#===========================================================================================
print "\n** Create JMS Activation Spec **"
# USAGE:  createJMSActivationSpec ( <"properties file name"> )
createJMSActivationSpec ( PROPS_HOME+"FacilityRelActivationSpec.props" )
createJMSActivationSpec ( PROPS_HOME+"NCRPubActivationSpec.props" )

#===========================================================================================
#  Create URL
#===========================================================================================
print "\n** Create URL **"
# USAGE:  createURL ( <"properties file name"> )
createURL ( PROPS_HOME+"NCtoFinalURL.props" )
createURL ( PROPS_HOME+"NtoCURL.props" )
createURL ( PROPS_HOME+"TRailProdUDS.props" )
createURL ( PROPS_HOME+"TRailTrainingUDS.props" )

#===========================================================================================
#  Save Configuration
#===========================================================================================
print "\n====== Saving configuration  ======"
AdminConfig.save()
syncNodesToMaster( nodeList )

print 'Done ...'






