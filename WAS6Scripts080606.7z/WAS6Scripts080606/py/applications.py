###############################################################################
# "This program may be used, executed, copied, modified and distributed without
# royalty for the purpose of developing, using, marketing, or distributing."
#
# Product 5630-A36 (C) COPYRIGHT International Business Machines Corp., 2006, 2007
# All Rights Reserved * Licensed Materials - Property of IBM
###############################################################################

#******************************************************************************
# File Name:	applications.py
# Description:	This file contains the following application-related procedures:
#		
#			markAppState
#			startApp
#			stopApp
#
# Author:		Gale Botwick - gbotwick@us.ibm.com
#
#******************************************************************************
#******************************************************************************
# File Name:   	markAppState
# Description:	Mark the application version of application disabled or enabled,
#			forcing synchronization.
#
# Author:      	Gale Botwick - gbotwick@us.ibm.com
#****************************************************************************** 
def markAppState ( appVersion, isEnabled ):

	#---------------------------------------------------------------------------------
	# Mark the version of the application code enabled or disabled
	#---------------------------------------------------------------------------------

	global AdminConfig
	print "\n ====== Mark "+appVersion+" with enable="+isEnabled+" ======"

	try:
		_excp_ = 0
		app = AdminConfig.getid("/Deployment:"+appVersion+"/" )
	except:
		_type_, _value_, _tbck_ = sys.exc_info()
		app = `_value_`
		_excp_ = 1
	#endTry 
	if (_excp_ ):
		print "Error getting AppVersion"
		print "server ID = "+app
		sys.exit()
	#endIf 

	do = AdminConfig.showAttribute(app, "deployedObject" )
	tm = AdminConfig.showAttribute(do, "targetMappings" )
	tml = first(tm)
	try:
		_excp_ = 0
		error = AdminConfig.modify(tml, [["enable", isEnabled]] )
	except:
		_type_, _value_, _tbck_ = sys.exc_info()
		error = `_value_`
		_excp_ = 1
	#endTry 
	if (_excp_ ):
		print "Error Marking Application"
		print "Error Message = "+error
		sys.exit()
	#endIf 

	print "Marking "+appVersion+" was successful."
	
#endDef


#******************************************************************************
# File Name:   	startApp
# Description:	Application start
#
# Author:      	Gale Botwick - gbotwick@us.ibm.com
#****************************************************************************** 
def startApp ( appName, serverName ):

	#---------------------------------------------------------------------------------
	# Start the application
	#---------------------------------------------------------------------------------

	global AdminControl
	print "\n ====== Start "+appName+" on "+serverName+" ======"

	rc = appControl("startApplication", appName, serverName)
	if (rc):
		print "Start Application "+appName+" failed."
	else:
		print "Start Application "+appName+" was successful."
	#endIf

#endDef

#******************************************************************************
# File Name:   	stopApp
# Description:	Application stop
#
# Author:      	Gale Botwick - gbotwick@us.ibm.com
#****************************************************************************** 
def stopApp ( appName, serverName ):

	#---------------------------------------------------------------------------------
	# Stop the application
	#---------------------------------------------------------------------------------

	global AdminControl

	print "\n ====== Stop "+appName+" on "+serverName+" ======"

	rc = appControl("stopApplication", appName, serverName)
	if (rc):
		print "Stop Application "+appName+" failed."
	else:
		print "Stop Application "+appName+" was successful."
	#endIf

#endDef

