/opt/IBM/WebSphere/AppServer/profiles/sleepyCellManager/bin/wsadmin.sh -lang jython -profile common.py -f main.py
