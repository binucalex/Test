###############################################################################
# "This program may be used, executed, copied, modified and distributed without
# royalty for the purpose of developing, using, marketing, or distributing."
#
# Product 5630-A36 (C) COPYRIGHT International Business Machines Corp., 2006, 2007
# All Rights Reserved * Licensed Materials - Property of IBM
###############################################################################

#******************************************************************************
# File Name:   	common.py
# Description: 	Used to setup variables used throughout other scripts.
# Author:      	Gale Botwick - gbotwick@us.ibm.com
# History:     
#******************************************************************************

#--------------------------------------------------------------------
# Setup Script Specific Paths
#--------------------------------------------------------------------
#SCRIPTS_HOME="/opt/IBM/WebSphere/scripts/redesign"
#WSADMIN_SCRIPTS_HOME=SCRIPTS_HOME+"/py"
#PROPS_HOME=SCRIPTS_HOME+"/props/"
SCRIPTS_HOME="/install/WID602/scripts/WAS6Scripts072506"
WSADMIN_SCRIPTS_HOME=SCRIPTS_HOME+"/py"
PROPS_HOME=SCRIPTS_HOME+"/props/"


#--------------------------------------------------------------------
# Setup WebSphere Network Deployment 6.0.2.x Paths
#--------------------------------------------------------------------
#ND_NAME="sleepyCellManager"
#WAS_ND_HOME="/opt/IBM/WebSphere/AppServer/profiles/$ND_NAME"
#WAS_ND_BIN=WAS_ND_HOME+"/bin"
#WAS_ND_CONFIG=WAS_ND_HOME+"/config"
#WAS_ND_LOGS=WAS_ND_HOME+"/logs"
ND_NAME="server1"
WAS_ND_HOME="/install/WID602/pf/wps/$ND_NAME"
WAS_ND_BIN=WAS_ND_HOME+"/bin"
WAS_ND_CONFIG=WAS_ND_HOME+"/config"
WAS_ND_LOGS=WAS_ND_HOME+"/logs"

#--------------------------------------------------------------------
# Setup WebSphere Cell Configuration
#--------------------------------------------------------------------
#cellName="RASMASTestRail"
#nodeList="sleepyNode,dopeyNode01"
#virtualHost="default_host"
cellName="widCell"
nodeList="widNode"
virtualHost="default_host"
